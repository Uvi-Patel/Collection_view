//
//  CollectionViewCell.swift
//  CollectionCiew_demo
//
//  Created by MAC on 10/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
//@IBOutlet weak var headerlbl: UILabel!
    @IBOutlet weak var imgOne: UIImageView!
    @IBOutlet weak var textLBL: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
//    func setData(text: String)
//    {
//        self.textLBL.text = text
//    }
}

class headerCollection: UICollectionReusableView
{
 
}
class footerCollection: UICollectionReusableView
{
    
}
