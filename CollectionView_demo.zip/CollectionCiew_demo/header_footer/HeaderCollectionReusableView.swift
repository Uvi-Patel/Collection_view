//
//  HeaderCollectionReusableView.swift
//  CollectionCiew_demo
//
//  Created by MAC on 11/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class HeaderCollectionReusableView: UICollectionReusableView {

    @IBOutlet weak var header: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    static let identifier = "HeaderCollectionReusableView"
        
    
        private let label:UILabel = {
            let label = UILabel()
            label.text = "HEADER"
            label.font = UIFont.italicSystemFont(ofSize: 25)
            label.textAlignment = .center
            label.textColor = .white
            return label
        }()
        
        public func configute() {
            backgroundColor = .systemRed
            layer.borderWidth = 1.5
            addSubview(label)
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            label.frame = bounds
        }
    }
class FooterCollectionReusableView: UICollectionReusableView{
        static let identifier = "FooterCollectionReusableView"
        
        private let label:UILabel = {
            let label = UILabel()
            label.text = "FOOTER"
            label.font = UIFont.italicSystemFont(ofSize: 20)
            label.textAlignment = .center
            label.textColor = .black
            return label
        }()
        
        public func configute() {
            backgroundColor = .systemGreen
            layer.borderWidth = 1.5
            addSubview(label)
        }
        
        override func layoutSubviews() {
            super.layoutSubviews()
            label.frame = bounds
        }
    }
