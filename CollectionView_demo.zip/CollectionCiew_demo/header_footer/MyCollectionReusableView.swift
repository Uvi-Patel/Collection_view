//
//  MyCollectionReusableView.swift
//  CollectionCiew_demo
//
//  Created by MAC on 11/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit

class MyCollectionReusableView: UICollectionReusableView {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
}
